'''
公共参数
'''

# 脚本文件地址，需要和salt指定的目录地址一致 测试服务器地址：/srv/salt/scripts
SH_PATH = "/srv/salt/scripts"