# -*- coding: utf-8 -*-
from BigScreen.settings.base import *
import logging
import arrow



############################Mysql数据库配置###################
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'HOST': 'mysql_jk',
        'PORT': 3306,
        'NAME': 'jk',
        'USER': 'jk',
        'PASSWORD': 'jk',
    }
}

############################redis配置########################
REDIS_HOST = "10.6.201.24"
REDIS_PASSWORD = "Unicom@12345"


############################日志配置##########################
loger_time = str(arrow.now().format('YYYY-MM-DD'))
os.path.join(BASE_DIR, 'log')
LOGGER_PATH = os.path.join(BASE_DIR, 'log', loger_time.split('-')[0], loger_time.split('-')[1], loger_time.split('-')[2])

if not os.path.exists(LOGGER_PATH):
    os.makedirs(LOGGER_PATH)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    # 格式化器
    'formatters': {
        # 日志格式
        'verbose': {
            'format': '[%(levelname)s]--%(asctime)s--[%(module)s] %(process)d [line:%(lineno)d] %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },

    },
    # 过滤器
    'filter': {
    },
    # 处理器
    'handlers': {
        'file': {
            'level': 'DEBUG',
            'class': 'logging.handlers.TimedRotatingFileHandler',
            'filename': os.path.join(LOGGER_PATH, 'collect.log'),
            'when': 'midnight',
            'interval': 1,
            'backupCount': 100,
            'formatter': 'verbose',
            'encoding': 'utf-8',
        },
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
    },
    # 记录器
    'loggers': {
        'bigscreen': {
            'handlers': ['file', 'console'],
            'level': 'INFO',
            'propagate': False
        },

    }
}




